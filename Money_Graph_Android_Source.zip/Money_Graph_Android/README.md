# Money Graph

Offline Android income / expense tracker with a trading-style graph.

## App
- Name: Money Graph
- Package: `com.moneygraph.app`
- Min Android: Android 10 (API 29)
- Target: Android 15 / API 35
- Storage: native SQLite (`money_graph.db`) through a JavaScript bridge
- UI: bundled offline V8 HTML/CSS/JS interface
- Network: not required

## Data persistence
Transactions, settings and backup-reminder state are stored in the app SQLite database and survive app restarts and phone reboots. Uninstalling the app removes app-local data, so use the JSON Backup action before uninstalling or moving phones.

## Export
CSV, JSON backup and chart PNG are written to `Downloads/Money Graph` using Android MediaStore.

## Build
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. It builds `app-debug.apk` as an installable APK artifact.
