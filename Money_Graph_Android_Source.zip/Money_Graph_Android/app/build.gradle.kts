plugins {
    id("com.android.application")
}

android {
    namespace = "com.moneygraph.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.moneygraph.app"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
