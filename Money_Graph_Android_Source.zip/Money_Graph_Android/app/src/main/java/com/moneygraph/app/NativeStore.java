package com.moneygraph.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.os.Environment;
import android.content.ContentResolver;
import android.net.Uri;
import android.util.Base64;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public final class NativeStore {
    private final Context context;
    private final Db db;

    NativeStore(Context context) {
        this.context = context.getApplicationContext();
        this.db = new Db(this.context);
    }

    @JavascriptInterface
    public String getItem(String key) {
        SQLiteDatabase r = db.getReadableDatabase();
        try (Cursor c = r.query("kv", new String[]{"v"}, "k=?", new String[]{key}, null, null, null, "1")) {
            return c.moveToFirst() ? c.getString(0) : null;
        }
    }

    @JavascriptInterface
    public void setItem(String key, String value) {
        SQLiteDatabase w = db.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("k", key);
        cv.put("v", value == null ? "" : value);
        w.insertWithOnConflict("kv", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    @JavascriptInterface
    public void removeItem(String key) {
        db.getWritableDatabase().delete("kv", "k=?", new String[]{key});
    }

    @JavascriptInterface
    public void saveTextFile(String name, String mimeType, String text) {
        try {
            writeDownload(name, mimeType, text.getBytes(StandardCharsets.UTF_8));
            toast("Saved to Downloads");
        } catch (Exception e) {
            toast("Save failed");
        }
    }

    @JavascriptInterface
    public void saveBase64File(String name, String mimeType, String base64) {
        try {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            writeDownload(name, mimeType, bytes);
            toast("Saved to Downloads");
        } catch (Exception e) {
            toast("Save failed");
        }
    }

    private void writeDownload(String name, String mimeType, byte[] bytes) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Money Graph");
        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("Cannot create download");
        try (OutputStream os = resolver.openOutputStream(uri)) {
            if (os == null) throw new IllegalStateException("Cannot open download");
            os.write(bytes);
            os.flush();
        }
    }

    private void toast(String message) {
        android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        h.post(() -> Toast.makeText(context, message, Toast.LENGTH_SHORT).show());
    }

    private static final class Db extends SQLiteOpenHelper {
        Db(Context context) {
            super(context, "money_graph.db", null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE kv (k TEXT PRIMARY KEY NOT NULL, v TEXT NOT NULL)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        }
    }
}
